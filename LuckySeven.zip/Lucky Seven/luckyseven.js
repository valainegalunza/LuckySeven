function play() {
  var bet = document.forms["lucky7Form"]["bet"].value;
  if (bet == 0 || isNaN(bet)) {
    alert("Provide Starting Bet");
    document.getElementById("results").style.display = "none";
    return false;
  }

  var dice1 = 0;
  var dice2 = 0;
  var diceTotal = 0;
  var dollar = bet
  var numRolls = 0;
  var amountWon = 0;
  var maxDollar = 0;
  var highestRoll = 0;

  do {
    numRolls++
    dice1 = Math.floor(Math.random() * 6) + 1;
    dice2 = Math.floor(Math.random() * 6) + 1;
    diceTotal = dice1 + dice2;

    if (diceTotal == 7) {
      dollar += 4;
      amountWon += 4;
    } else {
      dollar--;
      amountWon--;
    }

    if (maxDollar < amountWon) {
      maxDollar = amountWon
      highestRoll = numRolls
    }


  } while (dollar > 0);

  maxDollar = parseFloat(Math.round(maxDollar * 100) / 100).toFixed(2);
  bet = parseFloat(Math.round(bet * 100) / 100).toFixed(2);

  document.getElementById("results").style.display = "block";
  document.getElementById("playBtn").innerText = "Play";
  document.getElementById("firstBet").innerText = "$" + bet;
  document.getElementById("resultrollsBroke").innerText = numRolls;
  document.getElementById("resultsmaxAmount").innerText = "$" + maxDollar;
  document.getElementById("resultrollCount").innerText = highestRoll;
  return false;
}
